export default function Location() {
  const hours = [
    { d: "Monday", t: "12:00 – 24:00" },
    { d: "Tuesday", t: "12:00 – 24:00" },
    { d: "Wednesday", t: "12:00 – 24:00" },
    { d: "Thursday", t: "12:00 – 24:00" },
    { d: "Friday", t: "12:00 – 02:00" },
    { d: "Saturday", t: "12:00 – 02:00" },
    { d: "Sunday", t: "12:00 – 24:00" },
  ];

  return (
    <section id="location" className="relative py-28 md:py-40 bg-[#070705]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="text-center mb-16">
          <div className="reveal divider-gold mb-6">
            <span className="text-[10px] tracking-[0.5em] uppercase text-[#c9a961]">Find Us</span>
          </div>
          <h2 className="reveal reveal-delay-1 display text-5xl md:text-7xl text-white leading-none">
            Visit <span className="italic serif text-[#e6c887]">Gras</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Map */}
          <div className="reveal reveal-delay-2 lg:col-span-3 relative border border-white/10 overflow-hidden group">
            <iframe
              title="Gras Restaurant Lagos Map"
              src="https://www.google.com/maps?q=65+Adeola+Odeku+St,+Victoria+Island,+Lagos&output=embed"
              width="100%"
              height="100%"
              className="w-full h-[500px] grayscale contrast-125 opacity-90 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
            <div className="absolute top-6 left-6 bg-[#0a0908]/90 backdrop-blur border border-[#c9a961]/40 p-5 max-w-xs pointer-events-none">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-2 h-2 rounded-full bg-[#c9a961] animate-pulse" />
                <span className="text-[10px] tracking-[0.3em] uppercase text-[#c9a961]">Currently Open</span>
              </div>
              <div className="display text-xl text-white leading-tight">Gras Restaurant Lagos</div>
              <div className="text-xs text-white/60 mt-2 leading-relaxed">
                65 Adeola Odeku St,<br />Victoria Island, Lagos 101233
              </div>
            </div>
          </div>

          {/* Info */}
          <div className="lg:col-span-2 space-y-8">
            <div className="reveal reveal-delay-3 p-8 border border-white/10 bg-gradient-to-br from-white/[0.02] to-transparent">
              <h3 className="text-[10px] tracking-[0.4em] uppercase text-[#c9a961] mb-5">Opening Hours</h3>
              <ul className="space-y-2.5">
                {hours.map((h) => (
                  <li key={h.d} className="flex justify-between items-baseline text-sm">
                    <span className="text-white/70">{h.d}</span>
                    <span className="flex-1 mx-3 border-b border-dotted border-white/10 translate-y-[-3px]" />
                    <span className="serif text-white/90">{h.t}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="reveal reveal-delay-4 p-8 border border-white/10 bg-gradient-to-br from-white/[0.02] to-transparent space-y-4">
              <h3 className="text-[10px] tracking-[0.4em] uppercase text-[#c9a961] mb-3">Contact</h3>
              <InfoRow icon="📍" label="Address" value="65 Adeola Odeku St, Victoria Island, Lagos 101233" />
              <InfoRow icon="📞" label="Phone" value="0913 811 1444" href="tel:09138111444" />
              <InfoRow icon="✉" label="Email" value="hello@graslagos.com" href="mailto:hello@graslagos.com" />
              <InfoRow icon="💬" label="WhatsApp" value="Chat with us" href="https://wa.me/2349138111444" />
            </div>

            <div className="reveal reveal-delay-5 grid grid-cols-2 gap-3">
              <a
                href="https://www.google.com/maps/dir/?api=1&destination=65+Adeola+Odeku+St,+Victoria+Island,+Lagos"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-gold justify-center"
              >
                Directions
              </a>
              <a
                href="https://wa.me/2349138111444"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-outline justify-center"
              >
                WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function InfoRow({
  icon, label, value, href,
}: { icon: string; label: string; value: string; href?: string }) {
  const content = (
    <div className="flex items-start gap-4">
      <div className="w-10 h-10 border border-[#c9a961]/40 flex items-center justify-center text-[#c9a961] shrink-0">
        {icon}
      </div>
      <div>
        <div className="text-[9px] tracking-[0.3em] uppercase text-white/40">{label}</div>
        <div className="text-white/90 text-sm mt-1">{value}</div>
      </div>
    </div>
  );
  return href ? (
    <a href={href} className="block hover:opacity-80 transition-opacity">{content}</a>
  ) : (
    content
  );
}
