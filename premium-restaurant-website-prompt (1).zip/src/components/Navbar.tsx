import { useEffect, useState } from "react";

const links = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Menu", href: "#menu" },
  { label: "Gallery", href: "#gallery" },
  { label: "Reviews", href: "#reviews" },
  { label: "Reserve", href: "#reserve" },
  { label: "Visit", href: "#location" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [t, setT] = useState("");

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", on);
    on();
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => {
    const tick = () => {
      const d = new Date();
      setT(
        d.toLocaleTimeString("en-NG", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
          timeZone: "Africa/Lagos",
        })
      );
    };
    tick();
    const i = setInterval(tick, 1000 * 30);
    return () => clearInterval(i);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-700 ${
        scrolled
          ? "bg-[#0a0908]/85 backdrop-blur-xl border-b border-white/5 py-4"
          : "bg-transparent py-7"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10 flex items-center justify-between">
        <a href="#home" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-full border border-[#c9a961] flex items-center justify-center text-[#c9a961] display text-xl group-hover:rotate-180 transition-transform duration-700">
            G
          </div>
          <div className="flex flex-col leading-none">
            <span className="display text-2xl tracking-[0.25em] text-white">GRAS</span>
            <span className="text-[9px] tracking-[0.4em] text-[#c9a961]/80 uppercase mt-1">
              Lagos
            </span>
          </div>
        </a>

        <nav className="hidden lg:flex items-center gap-10">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-[11px] tracking-[0.3em] uppercase text-white/70 hover:text-[#c9a961] transition-colors link-underline"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-5">
          <div className="hidden md:flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
            </span>
            <span className="text-white/70">Open · {t}</span>
          </div>
          <a href="tel:09138111444" className="hidden md:inline-flex btn-gold !py-3 !px-5 !text-[10px]">
            Book Table
          </a>
          <button
            onClick={() => setOpen(!open)}
            className="lg:hidden w-10 h-10 flex flex-col items-center justify-center gap-1.5"
            aria-label="menu"
          >
            <span className={`w-6 h-[1px] bg-[#c9a961] transition-all ${open ? "rotate-45 translate-y-1" : ""}`} />
            <span className={`w-6 h-[1px] bg-[#c9a961] transition-all ${open ? "opacity-0" : ""}`} />
            <span className={`w-6 h-[1px] bg-[#c9a961] transition-all ${open ? "-rotate-45 -translate-y-1.5" : ""}`} />
          </button>
        </div>
      </div>

      {/* mobile */}
      <div className={`lg:hidden overflow-hidden transition-all duration-500 ${open ? "max-h-[500px] mt-4" : "max-h-0"}`}>
        <nav className="bg-[#0a0908]/95 backdrop-blur-xl border-t border-white/5 px-8 py-6 flex flex-col gap-5">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="text-xs tracking-[0.3em] uppercase text-white/80 hover:text-[#c9a961]"
            >
              {l.label}
            </a>
          ))}
          <a href="tel:09138111444" className="btn-gold mt-3 justify-center">
            Book a Table
          </a>
        </nav>
      </div>
    </header>
  );
}
