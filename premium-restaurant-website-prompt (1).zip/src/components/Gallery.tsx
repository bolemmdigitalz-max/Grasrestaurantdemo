const photos = [
  { src: "https://images.unsplash.com/photo-1600891964599-f61ba0e24092?auto=format&fit=crop&w=900&q=80", span: "md:col-span-2 md:row-span-2" },
  { src: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=700&q=80", span: "" },
  { src: "https://images.unsplash.com/photo-1470337458703-46ad1756a187?auto=format&fit=crop&w=700&q=80", span: "" },
  { src: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=700&q=80", span: "" },
  { src: "https://images.unsplash.com/photo-1560963689-02e82017f95c?auto=format&fit=crop&w=900&q=80", span: "md:col-span-2" },
  { src: "https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=700&q=80", span: "" },
  { src: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=900&q=80", span: "md:col-span-2" },
];

export default function Gallery() {
  return (
    <section id="gallery" className="relative py-28 md:py-40 bg-[#070705]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <div>
            <div className="reveal flex items-center gap-4 mb-6">
              <div className="h-[1px] w-12 bg-[#c9a961]" />
              <span className="text-[10px] tracking-[0.5em] uppercase text-[#c9a961]">Moments</span>
            </div>
            <h2 className="reveal reveal-delay-1 display text-5xl md:text-7xl text-white leading-none">
              Feast for <br /> <span className="italic serif text-[#e6c887]">the senses</span>
            </h2>
          </div>
          <p className="reveal reveal-delay-2 text-white/50 max-w-md">
            Take a look inside our dining room, the kitchen pass, and the plates our guests love.
            Tag us <span className="text-[#c9a961]">@graslagos</span> for a chance to be featured.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] md:auto-rows-[220px] gap-3">
          {photos.map((p, i) => (
            <div
              key={i}
              className={`reveal relative img-zoom group ${p.span}`}
              style={{ transitionDelay: `${i * 0.05}s` }}
            >
              <img src={p.src} alt="" className="w-full h-full object-cover" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0a0908]/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute bottom-4 left-4 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-500">
                <span className="text-[9px] tracking-[0.4em] uppercase text-[#c9a961]">Gras Lagos</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
