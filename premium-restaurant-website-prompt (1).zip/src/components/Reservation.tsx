import { useState } from "react";

export default function Reservation() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    date: "",
    time: "19:00",
    guests: "2",
    occasion: "",
    notes: "",
  });
  const [sent, setSent] = useState(false);

  const update = (k: string, v: string) => setForm((s) => ({ ...s, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <section id="reserve" className="relative py-28 md:py-40 overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-20"
        style={{
          backgroundImage:
            'url("https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1800&q=80")',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0908] via-[#0a0908]/95 to-[#0a0908]" />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <div>
            <div className="reveal flex items-center gap-4 mb-6">
              <div className="h-[1px] w-12 bg-[#c9a961]" />
              <span className="text-[10px] tracking-[0.5em] uppercase text-[#c9a961]">Book Your Table</span>
            </div>

            <h2 className="reveal reveal-delay-1 display text-5xl md:text-7xl leading-[0.95] text-white mb-8">
              Reserve your <br />
              <span className="italic serif text-[#e6c887]">evening</span>
            </h2>

            <p className="reveal reveal-delay-2 text-white/60 leading-relaxed mb-10 max-w-md">
              Reservations are essential at Gras. Secure your table below, or contact our
              concierge directly for private events and chef's table experiences.
            </p>

            <div className="reveal reveal-delay-3 space-y-5">
              {[
                { l: "Call Concierge", v: "0913 811 1444", href: "tel:09138111444" },
                { l: "WhatsApp", v: "Message us directly", href: "https://wa.me/2349138111444" },
                { l: "Email", v: "reserve@graslagos.com", href: "mailto:reserve@graslagos.com" },
              ].map((c) => (
                <a
                  key={c.l}
                  href={c.href}
                  className="flex items-center justify-between pb-4 border-b border-white/10 group hover:border-[#c9a961]/50 transition-colors"
                >
                  <div>
                    <div className="text-[10px] tracking-[0.3em] uppercase text-white/40">{c.l}</div>
                    <div className="display text-xl text-white mt-1 group-hover:text-[#c9a961] transition-colors">{c.v}</div>
                  </div>
                  <svg className="w-5 h-5 text-[#c9a961] group-hover:translate-x-1 transition-transform" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </svg>
                </a>
              ))}
            </div>
          </div>

          {/* Form */}
          <form
            onSubmit={submit}
            className="reveal reveal-delay-2 p-8 md:p-12 bg-gradient-to-br from-[#141211] to-[#0a0908] border border-white/10 relative"
          >
            <div className="absolute -top-px left-1/2 -translate-x-1/2 w-24 h-px bg-[#c9a961]" />

            {sent && (
              <div className="absolute inset-0 bg-[#0a0908]/95 backdrop-blur flex flex-col items-center justify-center z-10 text-center p-8">
                <div className="w-16 h-16 rounded-full border border-[#c9a961] flex items-center justify-center mb-6 glow-anim">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#c9a961" strokeWidth="1.5">
                    <path d="M20 6L9 17l-5-5" />
                  </svg>
                </div>
                <h3 className="display text-3xl text-white mb-3">Reservation received</h3>
                <p className="text-white/60 max-w-sm">Our concierge will confirm your table via WhatsApp within the hour.</p>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <Field label="Name" className="col-span-2">
                <input required value={form.name} onChange={(e) => update("name", e.target.value)} className="input" placeholder="Your full name" />
              </Field>
              <Field label="Email">
                <input required type="email" value={form.email} onChange={(e) => update("email", e.target.value)} className="input" placeholder="you@email.com" />
              </Field>
              <Field label="Phone">
                <input required value={form.phone} onChange={(e) => update("phone", e.target.value)} className="input" placeholder="+234..." />
              </Field>
              <Field label="Date">
                <input required type="date" value={form.date} onChange={(e) => update("date", e.target.value)} className="input" />
              </Field>
              <Field label="Time">
                <select value={form.time} onChange={(e) => update("time", e.target.value)} className="input">
                  {["17:00","17:30","18:00","18:30","19:00","19:30","20:00","20:30","21:00","21:30","22:00"].map(t=>(
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </Field>
              <Field label="Guests" className="col-span-2">
                <div className="flex flex-wrap gap-2">
                  {["1","2","3","4","5","6","7+"].map(g => (
                    <button
                      type="button"
                      key={g}
                      onClick={() => update("guests", g)}
                      className={`w-11 h-11 text-sm tracking-wider transition-all ${
                        form.guests === g
                          ? "bg-[#c9a961] text-[#0a0908]"
                          : "border border-white/10 text-white/70 hover:border-[#c9a961]/60"
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </Field>
              <Field label="Occasion (optional)" className="col-span-2">
                <select value={form.occasion} onChange={(e) => update("occasion", e.target.value)} className="input">
                  <option value="">None</option>
                  <option>Birthday</option>
                  <option>Anniversary</option>
                  <option>Proposal</option>
                  <option>Business</option>
                  <option>Celebration</option>
                </select>
              </Field>
              <Field label="Special requests" className="col-span-2">
                <textarea value={form.notes} onChange={(e) => update("notes", e.target.value)} rows={3} className="input resize-none" placeholder="Dietary requirements, seating preference..." />
              </Field>
            </div>

            <button type="submit" className="btn-gold w-full justify-center mt-8">
              Request Reservation →
            </button>

            <p className="text-[10px] tracking-widest uppercase text-white/40 text-center mt-5">
              Average allocation · 2 hours per table
            </p>
          </form>
        </div>
      </div>

      <style>{`
        .input {
          width: 100%;
          background: transparent;
          border: 0;
          border-bottom: 1px solid rgba(255,255,255,0.1);
          padding: 0.75rem 0;
          color: #f5efe4;
          font-size: 0.95rem;
          transition: border-color .3s;
          outline: none;
          font-family: inherit;
        }
        .input:focus { border-color: #c9a961; }
        .input::placeholder { color: rgba(255,255,255,0.3); }
        select.input option { background: #0a0908; }
      `}</style>
    </section>
  );
}

function Field({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="text-[9px] tracking-[0.3em] uppercase text-white/40 block mb-1">{label}</span>
      {children}
    </label>
  );
}
