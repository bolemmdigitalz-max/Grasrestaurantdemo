export default function About() {
  return (
    <section id="about" className="relative py-28 md:py-40 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
        {/* Image collage */}
        <div className="relative reveal">
          <div className="relative grid grid-cols-5 grid-rows-5 gap-4 h-[560px]">
            <div className="col-span-3 row-span-3 img-zoom rounded-sm overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&w=900&q=80"
                alt="Gras interior"
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="col-span-2 row-span-2 col-start-4 row-start-1 img-zoom rounded-sm overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=700&q=80"
                alt="Plated dish"
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="col-span-2 row-span-2 col-start-1 row-start-4 img-zoom rounded-sm overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=700&q=80"
                alt="Cocktail"
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="col-span-3 row-span-3 col-start-3 row-start-3 img-zoom rounded-sm overflow-hidden shadow-2xl border-2 border-[#c9a961]/50">
              <img
                src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=900&q=80"
                alt="Signature"
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="absolute -top-6 -left-6 w-24 h-24 border border-[#c9a961] -z-0" />
            <div className="absolute -bottom-6 -right-6 w-32 h-32 border border-[#c9a961] -z-0" />
          </div>

          <div className="absolute -right-4 top-8 rotate-12 w-28 h-28 rounded-full bg-[#c9a961] flex items-center justify-center glow-anim">
            <div className="text-center text-[#0a0908]">
              <div className="display text-xl leading-none">Since</div>
              <div className="display text-3xl leading-none mt-1">2019</div>
            </div>
          </div>
        </div>

        {/* Copy */}
        <div>
          <div className="reveal flex items-center gap-4 mb-6">
            <div className="h-[1px] w-12 bg-[#c9a961]" />
            <span className="text-[10px] tracking-[0.5em] uppercase text-[#c9a961]">Our Story</span>
          </div>

          <h2 className="reveal reveal-delay-1 display text-5xl md:text-7xl leading-[0.95] text-white mb-8">
            A love letter <br />
            to <span className="italic serif text-[#e6c887]">flavor</span>.
          </h2>

          <p className="reveal reveal-delay-2 text-white/70 text-lg leading-relaxed mb-6">
            Born in the heart of Victoria Island, Gras is more than a restaurant — it's a stage.
            Our chefs compose every plate like a score, balancing local Nigerian ingredients with
            continental technique, and serving them in a room that hums with quiet luxury.
          </p>
          <p className="reveal reveal-delay-3 text-white/60 leading-relaxed mb-10">
            From the crackle of open flame to the perfume of fresh herbs and the clink of crystal —
            every detail is rehearsed, every moment considered.
          </p>

          <div className="reveal reveal-delay-4 grid grid-cols-2 gap-x-10 gap-y-6 mb-10">
            {[
              { t: "Curated", d: "Seasonal tasting menu" },
              { t: "Crafted", d: "House cocktails & wines" },
              { t: "Considered", d: "Reservations only" },
              { t: "Cultured", d: "Live music weekly" },
            ].map((f) => (
              <div key={f.t} className="flex gap-4 items-start">
                <div className="mt-1 text-[#c9a961]">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M20 6L9 17l-5-5" />
                  </svg>
                </div>
                <div>
                  <div className="display text-xl text-white mb-1">{f.t}</div>
                  <div className="text-xs text-white/50 tracking-wide">{f.d}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="reveal reveal-delay-5">
            <a href="#menu" className="btn-gold">
              Discover the Menu →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
