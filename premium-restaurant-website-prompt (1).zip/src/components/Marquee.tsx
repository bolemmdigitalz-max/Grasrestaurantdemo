const items = [
  "Outdoor Seating",
  "Great Cocktails",
  "Reservations Required",
  "Open till Midnight",
  "Private Dining",
  "Valet Parking",
  "Live Music Fridays",
  "Chef's Table",
];

export default function Marquee() {
  return (
    <div className="relative border-y border-[#c9a961]/20 bg-[#0f0d0b] overflow-hidden py-6">
      <div className="marquee-track gap-14">
        {[...items, ...items, ...items].map((t, i) => (
          <div key={i} className="flex items-center gap-14 shrink-0">
            <span className="display text-3xl md:text-5xl text-[#c9a961]">✦</span>
            <span className="display text-2xl md:text-4xl tracking-wider text-white/90 uppercase">
              {t}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
