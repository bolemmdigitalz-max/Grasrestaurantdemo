export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden vignette">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center scale-105"
        style={{
          backgroundImage:
            'url("https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=2000&q=80")',
          animation: "scaleIn 2.5s ease-out both",
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0908]/80 via-[#0a0908]/50 to-[#0a0908]" />

      {/* Floating gold orb */}
      <div className="absolute top-1/4 -right-40 w-[500px] h-[500px] rounded-full bg-[#c9a961]/10 blur-[120px] float-anim" />
      <div className="absolute -bottom-40 -left-40 w-[600px] h-[600px] rounded-full bg-[#8e7834]/10 blur-[140px] float-anim" style={{ animationDelay: "2s" }} />

      {/* Spinning text badge */}
      <div className="absolute bottom-20 right-8 lg:right-16 z-20 hidden md:block">
        <div className="relative w-32 h-32 spin-slow">
          <svg viewBox="0 0 100 100" className="w-full h-full">
            <defs>
              <path id="circ" d="M 50,50 m -37,0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0" />
            </defs>
            <text fill="#c9a961" fontSize="8" letterSpacing="3" fontFamily="Inter">
              <textPath href="#circ">
                RESERVE · DINE · REPEAT · GRAS LAGOS ·
              </textPath>
            </text>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-[#c9a961] text-[#0a0908] flex items-center justify-center glow-anim">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10 w-full pt-32 pb-20">
        <div className="max-w-4xl">
          <div className="flex items-center gap-4 mb-8" style={{ animation: "fadeUp 1s ease-out .2s both" }}>
            <div className="h-[1px] w-14 bg-[#c9a961]" />
            <span className="text-[10px] tracking-[0.5em] uppercase text-[#c9a961]">
              Est. Victoria Island · Lagos
            </span>
          </div>

          <h1
            className="display text-[18vw] md:text-[11vw] lg:text-[9.5rem] leading-[0.9] text-white"
            style={{ animation: "fadeUp 1.2s ease-out .4s both" }}
          >
            Gras
          </h1>
          <h2
            className="serif italic text-4xl md:text-6xl text-[#e6c887] mt-2 mb-8 font-light"
            style={{ animation: "fadeUp 1.2s ease-out .7s both" }}
          >
            Where flavor <span className="not-italic display text-[#c9a961]">meets</span> fire.
          </h2>

          <p
            className="text-base md:text-lg text-white/70 max-w-xl leading-relaxed mb-10"
            style={{ animation: "fadeUp 1.2s ease-out 1s both" }}
          >
            A refined sanctuary of contemporary cuisine on Adeola Odeku — where curated plates,
            exceptional cocktails and candle-lit evenings define Lagos dining.
          </p>

          <div className="flex flex-wrap gap-5 items-center" style={{ animation: "fadeUp 1.2s ease-out 1.3s both" }}>
            <a href="#reserve" className="btn-gold">
              Reserve a Table
              <span aria-hidden>→</span>
            </a>
            <a href="#menu" className="btn-outline">
              Explore Menu
            </a>
          </div>

          {/* Stats */}
          <div className="mt-20 grid grid-cols-3 gap-6 max-w-2xl" style={{ animation: "fadeUp 1.2s ease-out 1.6s both" }}>
            {[
              { k: "4.4", v: "Google Rating" },
              { k: "283", v: "Guest Reviews" },
              { k: "₦50K+", v: "Per Person" },
            ].map((s) => (
              <div key={s.v} className="border-l border-[#c9a961]/40 pl-4">
                <div className="display text-4xl md:text-5xl gold-shimmer">{s.k}</div>
                <div className="text-[10px] tracking-[0.3em] uppercase text-white/50 mt-2">{s.v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3 z-20">
        <span className="text-[9px] tracking-[0.5em] uppercase text-white/50">Scroll</span>
        <div className="w-[1px] h-12 bg-gradient-to-b from-[#c9a961] to-transparent relative overflow-hidden">
          <div className="absolute inset-x-0 top-0 h-4 bg-white/80" style={{ animation: "floatY 2s ease-in-out infinite" }} />
        </div>
      </div>
    </section>
  );
}
