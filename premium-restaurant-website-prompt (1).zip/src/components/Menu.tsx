import { useState } from "react";

type Dish = { name: string; desc: string; price: string; tag?: string };

const menus: Record<string, Dish[]> = {
  Starters: [
    { name: "Seared Scallops & Mango", desc: "Pan-seared scallops, charred mango purée, toasted almond, micro herbs", price: "₦18,500", tag: "Signature" },
    { name: "Burrata & Heirloom Tomato", desc: "Creamy burrata, heirloom tomatoes, basil oil, aged balsamic", price: "₦14,000" },
    { name: "Tiger Prawn Cocktail", desc: "Atlantic prawns, Marie Rose, avocado, shaved iceberg", price: "₦16,500" },
    { name: "Smoked Duck Salad", desc: "Tea-smoked duck breast, orange, candied walnut, frisée", price: "₦17,000" },
  ],
  Mains: [
    { name: "Grass-Fed Filet Mignon", desc: "200g filet, truffle pomme purée, charred shallot, bone marrow jus", price: "₦42,000", tag: "Chef's Pick" },
    { name: "Lobster Thermidor", desc: "Whole Atlantic lobster, brandy cream, gruyère gratin", price: "₦58,000" },
    { name: "Jollof Risotto & Lamb", desc: "Smoked jollof risotto, slow-braised lamb shank, plantain crisp", price: "₦36,500" },
    { name: "Miso Black Cod", desc: "Sake-miso marinated cod, bok choy, ginger dashi", price: "₦38,000" },
  ],
  Desserts: [
    { name: "Dark Chocolate Soufflé", desc: "Valrhona 70%, vanilla bean crème anglaise, gold leaf", price: "₦12,500", tag: "Indulgent" },
    { name: "Crème Brûlée", desc: "Madagascar vanilla, burnt sugar, shortbread", price: "₦9,500" },
    { name: "Plantain Tatin", desc: "Caramelised plantain, puff pastry, rum raisin ice cream", price: "₦11,000" },
    { name: "Passion Fruit Pavlova", desc: "Meringue, tropical fruit coulis, toasted coconut", price: "₦10,500" },
  ],
  Cocktails: [
    { name: "Gras Old Fashioned", desc: "Bourbon, house bitters, demerara, orange oil", price: "₦9,500", tag: "House" },
    { name: "Lagos Sparkle", desc: "Champagne, hibiscus, lime, edible gold", price: "₦12,000" },
    { name: "Smoked Negroni", desc: "Gin, Campari, sweet vermouth, applewood smoke", price: "₦10,000" },
    { name: "Chapman Royal", desc: "House chapman cordial, prosecco, fresh fruit", price: "₦8,500" },
  ],
};

export default function Menu() {
  const [active, setActive] = useState<keyof typeof menus>("Starters");

  return (
    <section id="menu" className="relative py-28 md:py-40 bg-gradient-to-b from-[#0a0908] via-[#100d0a] to-[#0a0908]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="text-center mb-16">
          <div className="reveal divider-gold mb-6">
            <span className="text-[10px] tracking-[0.5em] uppercase text-[#c9a961]">The Menu</span>
          </div>
          <h2 className="reveal reveal-delay-1 display text-5xl md:text-7xl text-white leading-none mb-6">
            A Taste of <span className="italic serif text-[#e6c887]">Gras</span>
          </h2>
          <p className="reveal reveal-delay-2 text-white/60 max-w-xl mx-auto">
            Seasonal, produce-first cooking. Below is a glimpse — our menu evolves with the seasons.
          </p>
        </div>

        {/* Tabs */}
        <div className="reveal reveal-delay-3 flex flex-wrap justify-center gap-2 md:gap-4 mb-14">
          {Object.keys(menus).map((cat) => (
            <button
              key={cat}
              onClick={() => setActive(cat)}
              className={`relative px-6 py-3 text-[11px] tracking-[0.3em] uppercase transition-all duration-500 ${
                active === cat
                  ? "text-[#0a0908] bg-[#c9a961]"
                  : "text-white/60 hover:text-[#c9a961] border border-white/10"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Items */}
        <div className="grid md:grid-cols-2 gap-x-14 gap-y-10 max-w-5xl mx-auto">
          {menus[active].map((d, i) => (
            <div
              key={d.name}
              className="reveal group"
              style={{ transitionDelay: `${i * 0.08}s` }}
            >
              <div className="flex items-baseline justify-between gap-4 mb-2">
                <h3 className="display text-2xl text-white flex items-center gap-3">
                  {d.name}
                  {d.tag && (
                    <span className="text-[9px] tracking-[0.25em] uppercase text-[#0a0908] bg-[#c9a961] px-2 py-0.5">
                      {d.tag}
                    </span>
                  )}
                </h3>
                <div className="flex-1 border-b border-dotted border-white/15 translate-y-[-4px]" />
                <span className="serif text-xl text-[#c9a961] whitespace-nowrap">{d.price}</span>
              </div>
              <p className="text-sm text-white/55 leading-relaxed pr-8 group-hover:text-white/75 transition-colors">
                {d.desc}
              </p>
            </div>
          ))}
        </div>

        <div className="text-center mt-16 reveal">
          <p className="text-xs text-white/40 tracking-widest uppercase mb-5">
            Average spend ₦50,000+ per person · Reservations required
          </p>
          <a href="#reserve" className="btn-outline">
            Request the full menu →
          </a>
        </div>
      </div>
    </section>
  );
}
