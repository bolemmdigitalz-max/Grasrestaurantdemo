export default function Footer() {
  return (
    <footer className="relative bg-[#050504] border-t border-[#c9a961]/15 pt-20 pb-10 overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-40 bg-[#c9a961]/10 blur-[80px] rounded-full" />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-10">
        <div className="text-center mb-16">
          <div className="display text-[18vw] md:text-[12rem] leading-none gold-shimmer select-none">
            GRAS
          </div>
          <div className="divider-gold -mt-6">
            <span className="text-[10px] tracking-[0.5em] uppercase text-[#c9a961]">
              Fine Dining · Lagos
            </span>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-10 mb-14">
          <div className="md:col-span-2">
            <p className="serif italic text-2xl text-white/80 leading-relaxed max-w-md">
              "An experience crafted for the senses, rooted in the soul of Lagos."
            </p>
            <div className="flex gap-3 mt-8">
              {["Instagram", "Twitter", "Facebook", "TikTok"].map((s) => (
                <a
                  key={s}
                  href="#"
                  className="w-11 h-11 border border-[#c9a961]/40 flex items-center justify-center text-[#c9a961] text-xs hover:bg-[#c9a961] hover:text-[#0a0908] transition-all duration-500"
                  aria-label={s}
                >
                  {s[0]}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-[10px] tracking-[0.3em] uppercase text-[#c9a961] mb-5">Explore</h4>
            <ul className="space-y-3 text-sm text-white/60">
              <li><a href="#about" className="hover:text-[#c9a961] transition">About</a></li>
              <li><a href="#menu" className="hover:text-[#c9a961] transition">Menu</a></li>
              <li><a href="#gallery" className="hover:text-[#c9a961] transition">Gallery</a></li>
              <li><a href="#reserve" className="hover:text-[#c9a961] transition">Reservations</a></li>
              <li><a href="#reviews" className="hover:text-[#c9a961] transition">Reviews</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-[10px] tracking-[0.3em] uppercase text-[#c9a961] mb-5">Visit</h4>
            <ul className="space-y-3 text-sm text-white/60">
              <li>65 Adeola Odeku St</li>
              <li>Victoria Island, Lagos</li>
              <li className="text-[#c9a961]">0913 811 1444</li>
              <li>Open daily · Closes 12am</li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] tracking-widest uppercase text-white/40">
          <div>© {new Date().getFullYear()} Gras Restaurant Lagos · All Rights Reserved</div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-[#c9a961] transition">Privacy</a>
            <a href="#" className="hover:text-[#c9a961] transition">Terms</a>
            <a href="#" className="hover:text-[#c9a961] transition">Press</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
