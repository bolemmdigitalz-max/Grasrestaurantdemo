const exp = [
  {
    n: "01",
    t: "Chef's Table",
    d: "A six-course journey hosted at our pass. Watch the kitchen perform, dish by dish.",
    price: "₦95,000 / guest",
  },
  {
    n: "02",
    t: "Wine Pairing Dinners",
    d: "Monthly curated evenings with visiting sommeliers and rare vintages.",
    price: "From ₦70,000",
  },
  {
    n: "03",
    t: "Private Dining Room",
    d: "Secluded salon for celebrations of up to 12, with bespoke menus.",
    price: "On request",
  },
  {
    n: "04",
    t: "Terrace Evenings",
    d: "Outdoor seating under the Lagos sky with shisha and live jazz on Fridays.",
    price: "À la carte",
  },
];

export default function Experience() {
  return (
    <section className="relative py-28 md:py-40 overflow-hidden">
      <div className="absolute inset-0 opacity-30">
        <div
          className="absolute inset-0 bg-cover bg-center bg-fixed"
          style={{
            backgroundImage:
              'url("https://images.unsplash.com/photo-1551218808-94e220e084d2?auto=format&fit=crop&w=1800&q=80")',
          }}
        />
        <div className="absolute inset-0 bg-[#0a0908]/80" />
      </div>

      <div className="relative max-w-7xl mx-auto px-6 lg:px-10">
        <div className="text-center mb-20">
          <div className="reveal divider-gold mb-6">
            <span className="text-[10px] tracking-[0.5em] uppercase text-[#c9a961]">Experiences</span>
          </div>
          <h2 className="reveal reveal-delay-1 display text-5xl md:text-7xl text-white leading-none">
            Beyond <span className="italic serif text-[#e6c887]">dining</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {exp.map((e, i) => (
            <div
              key={e.n}
              className="reveal card-hover group relative p-10 border border-white/10 bg-gradient-to-br from-white/[0.02] to-transparent backdrop-blur-sm"
              style={{ transitionDelay: `${i * 0.1}s` }}
            >
              <div className="absolute top-0 left-0 w-10 h-px bg-[#c9a961] transition-all duration-700 group-hover:w-full" />
              <div className="absolute bottom-0 right-0 w-10 h-px bg-[#c9a961] transition-all duration-700 group-hover:w-full group-hover:left-0 group-hover:right-auto" />

              <div className="flex items-start justify-between mb-6">
                <span className="display text-[#c9a961]/50 text-6xl leading-none">{e.n}</span>
                <svg className="w-6 h-6 text-[#c9a961] transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M7 17L17 7M17 7H7M17 7v10" />
                </svg>
              </div>

              <h3 className="display text-3xl text-white mb-3">{e.t}</h3>
              <p className="text-white/60 leading-relaxed mb-6">{e.d}</p>
              <div className="text-[11px] tracking-[0.3em] uppercase text-[#c9a961]">{e.price}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
