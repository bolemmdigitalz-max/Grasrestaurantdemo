const reviews = [
  {
    name: "Adaeze O.",
    role: "Lagos · Food Blogger",
    text: "Every visit feels like an event. The filet is the best in the city — full stop. Service is attentive without being overbearing, and the room is beautiful.",
    rating: 5,
  },
  {
    name: "Tunde A.",
    role: "Abuja · Regular Guest",
    text: "We drive in from Abuja once a month just for Gras. The lobster thermidor is worth the flight. Dark, romantic, timeless.",
    rating: 5,
  },
  {
    name: "Ifeoma K.",
    role: "Victoria Island",
    text: "From the moment you walk in, you're wrapped in this warm, golden ambiance. Cocktails are world-class; the Gras Old Fashioned is dangerous.",
    rating: 5,
  },
  {
    name: "Chinedu E.",
    role: "Lekki",
    text: "Had our anniversary dinner here and they made it unforgettable. Handwritten card, complimentary dessert, perfect pacing. We'll be back.",
    rating: 4,
  },
];

function Stars({ n }: { n: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <svg key={s} width="14" height="14" viewBox="0 0 24 24" fill={s <= n ? "#c9a961" : "none"} stroke="#c9a961" strokeWidth="1.5">
          <polygon points="12 2 15 9 22 9.5 17 14.5 18.5 22 12 18 5.5 22 7 14.5 2 9.5 9 9" />
        </svg>
      ))}
    </div>
  );
}

export default function Reviews() {
  return (
    <section id="reviews" className="relative py-28 md:py-40 bg-gradient-to-b from-[#0a0908] to-[#0f0d0b]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="text-center mb-20">
          <div className="reveal flex items-center justify-center gap-3 mb-6">
            <Stars n={5} />
            <span className="text-[10px] tracking-[0.4em] uppercase text-[#c9a961]">4.4 · 283 reviews</span>
          </div>
          <h2 className="reveal reveal-delay-1 display text-5xl md:text-7xl text-white leading-none mb-4">
            Loved by <span className="italic serif text-[#e6c887]">Lagos</span>
          </h2>
          <p className="reveal reveal-delay-2 text-white/50 max-w-xl mx-auto">
            Real words from our guests. We're humbled by every word.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
          {reviews.map((r, i) => (
            <div
              key={r.name}
              className="reveal card-hover p-10 border border-white/10 bg-gradient-to-br from-white/[0.02] to-transparent relative group"
              style={{ transitionDelay: `${i * 0.1}s` }}
            >
              <div className="absolute top-6 right-8 display text-8xl text-[#c9a961]/15 leading-none select-none">
                "
              </div>

              <Stars n={r.rating} />
              <p className="serif italic text-xl md:text-2xl text-white/90 leading-relaxed my-6">
                "{r.text}"
              </p>
              <div className="flex items-center gap-4 pt-4 border-t border-white/5">
                <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#c9a961] to-[#8e7834] flex items-center justify-center text-[#0a0908] display text-lg">
                  {r.name[0]}
                </div>
                <div>
                  <div className="text-white text-sm font-medium">{r.name}</div>
                  <div className="text-[11px] tracking-widest uppercase text-white/40">{r.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12 reveal">
          <a
            href="https://www.google.com/maps"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs tracking-[0.3em] uppercase text-[#c9a961] link-underline"
          >
            Read all 283 reviews on Google →
          </a>
        </div>
      </div>
    </section>
  );
}
