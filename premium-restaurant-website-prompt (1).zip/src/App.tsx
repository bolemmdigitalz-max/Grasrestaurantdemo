import { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Menu from "./components/Menu";
import Experience from "./components/Experience";
import Gallery from "./components/Gallery";
import Reviews from "./components/Reviews";
import Reservation from "./components/Reservation";
import Location from "./components/Location";
import Footer from "./components/Footer";
import Marquee from "./components/Marquee";

export default function App() {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const p = setInterval(() => {
      setProgress((v) => (v >= 100 ? 100 : v + 4));
    }, 30);
    const t = setTimeout(() => {
      setLoading(false);
      clearInterval(p);
    }, 1200);
    return () => {
      clearTimeout(t);
      clearInterval(p);
    };
  }, []);

  useEffect(() => {
    if (loading) return;
    const els = document.querySelectorAll<HTMLElement>(".reveal");
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [loading]);

  if (loading) {
    return (
      <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-[#0a0908]">
        <div className="display text-5xl md:text-7xl gold-shimmer mb-8">GRAS</div>
        <div className="w-64 h-[1px] bg-white/10 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#8e7834] via-[#e6c887] to-[#8e7834] transition-all duration-75"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mt-4 text-[10px] tracking-[0.4em] text-white/50 uppercase">
          Crafting your experience
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="noise" />
      <Navbar />
      <main>
        <Hero />
        <Marquee />
        <About />
        <Menu />
        <Experience />
        <Gallery />
        <Reviews />
        <Reservation />
        <Location />
      </main>
      <Footer />
    </>
  );
}
